# My Lineman Application

- clone me
- npm install -g lineman
- npm install
- lineman run
